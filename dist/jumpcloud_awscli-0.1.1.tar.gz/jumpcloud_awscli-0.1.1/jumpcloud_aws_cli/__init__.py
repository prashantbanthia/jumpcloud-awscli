"""
JumpCloud AWS CLI Authentication Utility

This package provides utilities for authenticating with AWS CLI using JumpCloud SAML
and Device Trust certificates.
"""

__version__ = "0.1.1"